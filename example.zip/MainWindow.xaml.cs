﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace EnhancedComponents
{
    /// <summary>
    /// Interaktionslogik für MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            string examplePath = AppDomain.CurrentDomain.BaseDirectory + "\\Example";
            Hierarchy.filesystem = examplePath;
        }

        public HierarchyItem moveItem = null;
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (Hierarchy.SelectedHierarchyItem == null)
                return;

            // You can't move the root item anyway, but we use it here to disable the buttons in the correct way
            if (Hierarchy.SelectedHierarchyItem.isRoot == false)
            {
                moveItem = Hierarchy.SelectedHierarchyItem;
                MoveBegin.IsEnabled = false;
                MoveEnd.IsEnabled = true;
                moveItem.IsEnabled = false; // Disable the SelectedItem => Prevent moving the selected folder inside the selected folder, which is not possible. 
                moveItem = Hierarchy.SelectedHierarchyItem;
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            if (Hierarchy.SelectedHierarchyItem == null)
                return;

            moveItem.Move(Hierarchy.SelectedHierarchyItem);
            MoveBegin.IsEnabled = true;
            MoveEnd.IsEnabled = false;
            moveItem.IsEnabled = true;
        }

        private void Hierarchy_SelectedItemChanged(object sender, RoutedPropertyChangedEventArgs<object> e)
        {

            filenameTextBox.Text = Hierarchy.SelectedHierarchyItem.filename;
        }

        private void RenameButton_Click(object sender, RoutedEventArgs e)
        {
            if (Hierarchy.SelectedHierarchyItem == null)
                return;
            Hierarchy.SelectedHierarchyItem.filename = filenameTextBox.Text;
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            if (Hierarchy.SelectedHierarchyItem == null)
                return;

            if (MessageBox.Show("Delete " + Hierarchy.SelectedHierarchyItem.filename + "?","Delete",MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                Hierarchy.SelectedHierarchyItem.Delete();
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            if (Hierarchy.SelectedHierarchyItem == null)
                return;

            Hierarchy.SelectedHierarchyItem.OpenFolder();
        }

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            if (Hierarchy.SelectedHierarchyItem == null)
                return;

            Hierarchy.SelectedHierarchyItem.CreateHierarchyItem(HierarchyType.Folder, FolderTextBox.Text, ".txt");
        }

        private void Button_Click_5(object sender, RoutedEventArgs e)
        {
            if (Hierarchy.SelectedHierarchyItem == null)
                return;

            Hierarchy.SelectedHierarchyItem.CreateHierarchyItem(HierarchyType.File, FileTextBox.Text, ".txt");
        }
    }
}
